require 'test/unit'
require 'lib/wine_dot_com_api_request'