class WineDotComApiRequest
  @@api_key     = '3scale-f93cfbd11c88c117e476f6a6755bc15b'
  @@base_url    = 'API_KEY_HERE'
end